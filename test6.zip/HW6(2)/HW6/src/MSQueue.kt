import java.util.concurrent.atomic.*

/**
 * @author TODO: Last Name, First Name
 */
class MSQueue<E> : Queue<E> {
    private val head: AtomicReference<Node<E>>
    private val tail: AtomicReference<Node<E>>

    init {
        val dummy = Node<E>(null)
        head = AtomicReference(dummy)
        tail = AtomicReference(dummy)
    }

    override fun enqueue(element: E) {
        val newNode = Node(element)
        while (true) {
            val tailNode = tail.get()
            val nextNode = tailNode.next.get()
            if (tailNode == tail.get()) {
                if (nextNode == null) {
                    if (tailNode.next.compareAndSet(null, newNode)) {
                        tail.compareAndSet(tailNode, newNode)
                        return
                    }
                } else {
                    tail.compareAndSet(tailNode, nextNode)
                }
            }
        }
    }


    override fun dequeue(): E? {
        while (true) {
            val headNode = head.get()
            val tailNode = tail.get()
            val nextNode = headNode.next.get()
            if (headNode == head.get()) {
                if (headNode == tailNode) {
                    if (nextNode == null) return null
                    tail.compareAndSet(tailNode, nextNode)
                } else {
                    val value = nextNode?.element
                    if (head.compareAndSet(headNode, nextNode)) {
                        return value
                    }
                }
            }
        }
    }

    // FOR TEST PURPOSE, DO NOT CHANGE IT.
    override fun validate() {
        check(tail.get().next.get() == null) {
            "At the end of the execution, `tail.next` must be `null`"
        }
        check(head.get().element == null) {
            "At the end of the execution, the dummy node shouldn't store an element"
        }
    }

    private class Node<E>(
        var element: E?
    ) {
        val next = AtomicReference<Node<E>?>(null)
    }
}
